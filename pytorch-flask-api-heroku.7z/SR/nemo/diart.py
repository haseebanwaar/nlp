# Manipulate sound
import audioread
from IPython.display import Audio
import librosa
from pydub import AudioSegment, silence

# Load models & metrics to evaluate results
from transformers import Wav2Vec2Tokenizer, Wav2Vec2ForCTC
import torch
from pyannote.audio import Pipeline

# Others (Text & time process, system navigation)
import pandas as pd
from datetime import timedelta
import os
#%%
# folder's path
dir_path = "./workspace/audio_chunks"

# if folder does not exist, we create it
if not os.path.exists(dir_path):
    os.makedirs(dir_path)
    #%%
# Load speech to text model
stt_tokenizer = Wav2Vec2Tokenizer.from_pretrained("facebook/wav2vec2-base-960h")
stt_model = Wav2Vec2ForCTC.from_pretrained("facebook/wav2vec2-base-960h")



#%%
def transcribe_audio_part(filename, stt_model, stt_tokenizer, myaudio, sub_start, sub_end, index):
    """
    Transcribe an audio between a sub_start and a sub_end value (s)
    :param filename: name of the audio file
    :param stt_model: Wav2Vec2 Model (Speech to text model)
    :param stt_tokenizer: Wav2Vec2’s Tokenizer (Speech to text model's tokenizer)
    :param myaudio: AudioSegment file
    :param sub_start: start value (s) of the considered audio part to transcribe
    :param sub_end: end value (s) of the considered audio part to transcribe
    :param index: audio file counter

    :return: transcript of the considered audio (only in uppercases, so we add lower() to make the reading easier)
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    try:
        with torch.no_grad():
            new_audio = myaudio[sub_start:sub_end]  # Works in milliseconds
            path = "./workspace/audio_chunks/" + filename[:-3] + str(index) + ".wav"


            print(filename)
            new_audio.export(path,format='wav' )  # Exports to a mp3 file in the current path.

            # Load audio file with librosa, set sound rate to 16000 Hz because the model we use was trained on 16000 Hz data.
            input_audio, _ = librosa.load(path, sr=16000)

            # return PyTorch torch.Tensor instead of a list of python integers thanks to return_tensors = ‘pt’
            input_values = stt_tokenizer(input_audio,
                                         return_tensors="pt").to(device).input_values

            # Get logits from the data structure containing all the information returned by the model and get our prediction
            logits = stt_model.to(device)(input_values).logits
            prediction = torch.argmax(logits, dim=-1)

            # Decode & lower our string (model's output is only uppercase)
            transcript = stt_tokenizer.batch_decode(prediction)[0]
            return transcript.lower()

    except audioread.NoBackendError:
        # Means we have a chunk with a [value1 : value2] case with value1>value2
        print("Sorry, seems we have a problem on our side. Please change start & end values.")

        # Stop
        exit()

#%%
def detect_silences(audio):
    # Get Decibels (dB) so silences detection depends on the audio instead of a fixed value
    dbfs = audio.dBFS

    # Get silences timestamps > 750ms
    silence_list = silence.detect_silence(audio, min_silence_len=750, silence_thresh=dbfs - 14)
    return silence_list
#%%
def get_middle_values(silence_list):
    # Replace timestamps by their middle value
    new_silence_list=[]
    for timestamp in silence_list:
        new_silence_list.append(timestamp[0]+(timestamp[1]-timestamp[0])/2)
    return new_silence_list
def silences_distribution(silence_list, min_space, max_space, start, end, srt_token=False):
    """
    We keep each silence value if it is sufficiently distant from its neighboring values, without being too much
    :param silence_list: List with silences intervals
    :param min_space: Minimum temporal distance between two silences
    :param max_space: Maximum temporal distance between two silences
    :param start: int value (seconds)
    :param end: int value (seconds)
    :param srt_token: Enable/Disable generate srt file (choice fixed by user)
    :return: list with equally distributed silences
    """
    # If starts != 0, we need to adjust end value since silence detection is performed on the cropped audio (and not on the original audio)

    # Shift the end according to the start value
    end -= start
    start = 0
    end *= 1000

    # Step 1 - Adding start value
    newsilence = [start]

    # Step 2 - Create a regular distribution between start and the first element of silence_list to don't have a gap > max_space and run out of memory
    # example newsilence = [0] and silence_list starts with 100000 => It will create a massive gap [0, 100000]

    if silence_list[0] - max_space > newsilence[0]:
        for i in range(int(newsilence[0]), int(silence_list[0]), max_space):  # int bc float can't be in a range loop
            value = i + max_space
            if value < silence_list[0]:
                newsilence.append(value)

    # Step 3 - Create a regular distribution until the last value of the silence_list
    min_desired_value = newsilence[-1]
    max_desired_value = newsilence[-1]
    nb_values = len(silence_list)

    while nb_values != 0:
        max_desired_value += max_space

        # Get a window of the values greater than min_desired_value and lower than max_desired_value
        silence_window = list(filter(lambda x: min_desired_value < x <= max_desired_value, silence_list))

        if silence_window != []:
            # Get the nearest value we can to min_desired_value or max_desired_value depending on srt_token
            if srt_token:
                nearest_value = min(silence_window, key=lambda x: abs(x - min_desired_value))
                nb_values -= silence_window.index(nearest_value) + 1  # (index begins at 0, so we add 1)
            else:
                nearest_value = min(silence_window, key=lambda x: abs(x - max_desired_value))
                # Max value index = len of the list
                nb_values -= len(silence_window)

            # Append the nearest value to our list
            newsilence.append(nearest_value)

        # If silence_window is empty we add the max_space value to the last one to create an automatic cut and avoid multiple audio cutting
        else:
            newsilence.append(newsilence[-1] + max_space)

        min_desired_value = newsilence[-1]
        max_desired_value = newsilence[-1]

    # Step 4 - Add the final value (end)

    if end - newsilence[-1] > min_space:
        # Gap > Min Space
        if end - newsilence[-1] < max_space:
            newsilence.append(end)
        else:
            # Gap too important between the last list value and the end value
            # We need to create automatic max_space cut till the end
            newsilence = generate_regular_split_till_end(newsilence, end, min_space, max_space)
    else:
        # Gap < Min Space <=> Final value and last value of new silence are too close, need to merge
        if len(newsilence) >= 2:
            if end - newsilence[-2] <= max_space:
                # Replace if gap is not too important
                newsilence[-1] = end
            else:
                newsilence.append(end)

        else:
            if end - newsilence[-1] <= max_space:
                # Replace if gap is not too important
                newsilence[-1] = end
            else:
                newsilence.append(end)

    return newsilence


def generate_regular_split_till_end(time_list, end, min_space, max_space):
    """
    Add automatic "time cuts" to time_list till end value depending on min_space and max_space value
    :param time_list: silence time list
    :param end: int value (s)
    :param min_space: Minimum temporal distance between two silences
    :param max_space: Maximum temporal distance between two silences
    :return: list with automatic time cuts
    """
    # In range Loop can't handle float values so we convert to int
    int_last_value = int(time_list[-1])
    int_end = int(end)

    # Add maxspace to the last list value and add this value to the list
    for i in range(int_last_value, int_end, max_space):
        value = i + max_space
        if value < end:
            time_list.append(value)

    # Fix last automatic cut
    # If small gap (ex: 395 000, with end = 400 000)
    if end - time_list[-1] < min_space:
        time_list[-1] = end
    else:
        # If important gap (ex: 311 000 then 356 000, with end = 400 000, can't replace and then have 311k to 400k)
        time_list.append(end)
    return time_list

#%%
dia_pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization")
# Get an audio file where there are several speakers
filename = "a.wav"

# Create an audio segment from it
conversation_audio = AudioSegment.from_file("./SR/pyannote/" + filename)
#%%
def convert_file_to_wav(aud_seg, filename):
    """
    Convert a mp3/mp4 in a wav format
    Needs to be modified if you want to convert a format which contains less or more than 3 letters

    :param aud_seg: pydub.AudioSegment
    :param filename: name of the file
    :return: name of the converted file
    """
    filename =  filename[:-3] + "wav" #folder
    file_path = "./SR/pyannote/" + filename
    aud_seg.export(file_path, format="wav")

    newaudio = AudioSegment.from_file(file_path)

    return newaudio, filename
# Convert mp3/mp4 to wav (Differentiate speakers mode only accepts wav files)
if filename.endswith((".mp3", ".mp4")):
    conversation_audio, filename = convert_file_to_wav(conversation_audio, filename)

#%%
def get_diarization(dia_pipeline, filename):
    """
    Diarize an audio (find numbers of speakers, when they speak, ...)
    :param dia_pipeline: Pyannote's library diarization model
    :param filename: name of a wav audio file
    :return: str list containing audio's diarization time intervals
    """
    # Get diarization of the audio
    diarization = dia_pipeline({'audio': "./SR/pyannote/" + filename})

    # Rename default speakers' names (Default is A, B, ...), we want Speaker0, Speaker1, ...
    listmapping = diarization.labels()
    listnewmapping = []

    number_of_speakers = len(listmapping)
    for i in range(number_of_speakers):
        listnewmapping.append("Speaker" + str(i))

    mapping_dict = dict(zip(listmapping, listnewmapping))

    diarization.rename_labels(mapping_dict,
                              copy=False)  # copy set to False so we don't create a new annotation, we replace the actual one

    return diarization, number_of_speakers
#%%
# Differentiate speakers process
diarization, number_of_speakers = get_diarization(dia_pipeline, filename)

#%%
def convert_dia_results_to_timedelta(diarization_result, start):
    """
    Extract from diarization result the given speakers with their respective speaking times and transform them in pandas timedelta objects
    :param diarization_result: result of diarization
    :return: list with timedelta intervals and its respective speaker
    """

    segments = diarization_result.for_json()["content"]
    diarization_timestamps = []
    for sample in segments:
        new_seg = [pd.Timedelta(seconds=round(sample["segment"]["start"] + start, 2)),
                   pd.Timedelta(seconds=round(sample["segment"]["end"] + start, 2)), sample["label"]]
        # start and end = speaking duration
        # label = who is speaking
        diarization_timestamps.append(new_seg)

    return diarization_timestamps
def merge_speaker_times(diarization_timestamps, max_space, srt_token = False):
    """
    Merge near times for each detected speaker. (Same speaker during 1-2s and 3-4s -> Same speaker during 1-4s)
    :param diarization_timestamps: diarization list
    :param srt_token: Enable/Disable generate srt file (choice fixed by user)
    :return: list
    """
    if not srt_token:
        threshold = pd.Timedelta(seconds=max_space/1000)

        index = 0
        length = len(diarization_timestamps) - 1

        while index < length:
            if diarization_timestamps[index + 1][2] == diarization_timestamps[index][2] and diarization_timestamps[index + 1][0] - threshold <= diarization_timestamps[index][0]:
                diarization_timestamps[index][1] = diarization_timestamps[index + 1][1]
                del diarization_timestamps[index + 1]
                length -= 1
            else:
                index += 1
    return diarization_timestamps

def extanding_timestamps(new_diarization_timestamps):
    """
    Extand timestamps between each diarization if possible, so we avoid word cutting
    :param new_diarization_timestamps: list
    :return: list with merged times
    """
    for i in range(1, len(new_diarization_timestamps)):
        if new_diarization_timestamps[i][0] - new_diarization_timestamps[i - 1][1] <= timedelta(milliseconds=3000) and new_diarization_timestamps[i][0] - new_diarization_timestamps[i - 1][1] >= timedelta(milliseconds=100):
            middle = (new_diarization_timestamps[i][0] - new_diarization_timestamps[i - 1][1]) / 2
            new_diarization_timestamps[i][0] -= middle
            new_diarization_timestamps[i - 1][1] += middle

    # Convert list elements so we have a milliseconds format
    for elt in new_diarization_timestamps:
        elt[0] = elt[0].total_seconds() * 1000
        elt[1] = elt[1].total_seconds() * 1000

    return new_diarization_timestamps
#%%


if len(diarization) > 0:
    diarization_timestamps = convert_dia_results_to_timedelta(diarization, start=0)
    diarization_timestamps = merge_speaker_times(diarization_timestamps, max_space=45000)
    diarization_timestamps = extanding_timestamps(diarization_timestamps)
#%%
print(diarization_timestamps)

#%%
# Need to convert in a list of lists if we don't have one. (only the case with very short audio files)
if not isinstance(diarization_timestamps[0], list):
    diarization_timestamps = [diarization_timestamps]

# Create a list where transcript will be saved. It will be used after.
save_result_list = []

# Transcript audio
for index, elt in enumerate(diarization_timestamps):
    sub_start = elt[0]
    sub_end = elt[1]

    temp_transcript = transcribe_audio_part(filename, stt_model, stt_tokenizer, conversation_audio, sub_start, sub_end,
                                            index)

    temp_timestamps = str(timedelta(milliseconds=sub_start)).split(".")[0] + " --> " + \
                      str(timedelta(milliseconds=sub_end)).split(".")[0] + "\n"

    # Create a string with speaker's name and the transcript
    complete_temp_transcript = elt[2] + ": " + temp_transcript

    # Display timestamps and the respective string
    print(temp_timestamps)
    print(complete_temp_transcript + "\n\n")

    # Add result to the list, so we can use it after
    save_result_list.append([temp_timestamps, int(elt[2][-1]), elt[2], " : " + temp_transcript, int(sub_start / 1000)])


#%%
if number_of_speakers > 0:
    # Save the Speaker Name and its ID in a list, example : [1, 'Speaker1']
    list_of_speakers = []
    for elt in save_result_list:
        if [elt[1], elt[2]] not in list_of_speakers:
            list_of_speakers.append([elt[1], elt[2]])

    # Sort (by ID) so we do not have an unsorted case like [1, 'Speaker1'], [0, 'Speaker0']]
    list_of_speakers.sort()

    print(list_of_speakers)
#%%
# Do not change the name_index value. It indicates the index of the name in the list_of_speakers list.
name_index = 1

# Change names
list_of_speakers[0][name_index] = "Agnes"
list_of_speakers[1][name_index] = "Mirek"
list_of_speakers[2][name_index] = "French speaker"

#%%
for elt in save_result_list:
    elt[2] = list_of_speakers[elt[1]][1]
    print(elt[0], elt[2] + elt[3] + "\n", sep='')

#%%

















