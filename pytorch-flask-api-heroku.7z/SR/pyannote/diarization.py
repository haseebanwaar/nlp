from pyannote.audio import Pipeline
import matplotlib.pyplot as plt
from pyannote.core import notebook

pipeline = Pipeline.from_pretrained("pyannote/pyannote-diarization")
# diarization = pipeline("audio.wav", min_speakers=2, max_speakers=5)

output = pipeline("./pyannote/a.wav")

# %%

output.rename_labels({'SPEAKER_00': 'ali', 'SPEAKER_01': 'asad', 'SPEAKER_02': 'pop'}, copy=False)
output.labels()

# %%
# inference on an excerpt
from pyannote.core import Segment

excerpt = Segment(start=30.0, end=60)

from pyannote.audio import Audio

waveform, sample_rate = Audio().crop("./pyannote/a.wav", excerpt)
pipeline({"waveform": waveform, "sample_rate": sample_rate})

# %%

# INFERENcing from FITETRAINE MODELS
# from pyannote.audio import Inference
#
# inference = Inference("pyannote/pyannote-diarization")
#
# seg = inference("1_trimmed_short.wav")


# %%

figure, ax = plt.subplots()
notebook.plot_annotation(output, ax=ax, time=True, legend=True)
# plt.gcf()
plt.show()
